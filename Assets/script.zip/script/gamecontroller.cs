using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gamecontroller : MonoBehaviour
{
    public GameObject GoalObj;

    // Use this for initialization
    void Start () {
        GoalObj.SetActive(false);
    }

    // Update is called once per frame
    void Update () {

    }

    private void OnTriggerEnter(Collider collider){
        if (collider.gameObject.tag == "Player"){
            GoalObj.SetActive(true);
            Debug.Log("GOAL");
        }
    }
}
